#!/usr/bin/env node

/*
Module name: committee.js
Description: Contains the function which passes committee registration details to store in the database.
@param questions This is an array which contains the parameters given below
@param C_name This is the parameter that takes name of the committee
@param Sec_name This is the parameter that takes name of the committee secretary
@param Website This is the parameter that takes website URL of the committee
@param Contact This is the parameter that takes the contact number of the committee
@param Email This is the parameter that takes the user email address of the committee
Last edited by: Mayurigauri Sangle
Date: 05-10-2018
*/

const program = require('commander');
// Require logic.js file and extract controller functions using JS destructuring assignment
const {
    addComm,
    getComm,
    getCommList,
    updateComm,
    deleteComm,
} = require('./logic');

const { prompt } = require('inquirer'); // require inquirerjs library

// Craft questions to present to users
const questions = [
    {
        type: 'input',
        name: 'C_name',
        message: 'Enter committee name ...'
    },
    {
        type: 'input',
        name: 'Sec_name',
        message: 'Enter secretary name ...'
    },
    {
        type: 'input',
        name: 'Website',
        message: 'Enter website URL ...'
    },
    {
        type: 'input',
        name: 'Contact',
        message: 'Enter phone number ...'
    },
    {
        type: 'input',
        name: 'Email',
        message: 'Enter email address ...'
    }
];

program
    .version('0.0.1')
    .description('VJTI Online Portal');

program
    .command('addComm') // No need of specifying arguments here
    .alias('a')
    .description('Add a committee')
    .action(() => {
        // sends user input to addComm method
        prompt(questions).then(answers =>
            addComm(answers));
    });

program
    .command('getComm <name>')
    .alias('r')
    .description('Get committee')
    .action(name => getComm(name)); // sends user input to getComm method

program
    .command('updateComm <_id>')
    .alias('u')
    .description('Update committee')
    .action(_id => {
        // sends user input to updateComm method
        prompt(questions).then((answers) =>
            updateComm(_id, answers));
    });

program
    .command('deleteComm <_id>')
    .alias('d')
    .description('Delete committee')
    .action(_id => deleteComm(_id)); // sends user input to deleteComm method

program
    .command('getCommList')
    .alias('l')
    .description('List committees')
    .action(() => getCommList()); // sends user input to getCommList method

// Assert that a VALID command is provided 
if (!process.argv.slice(2).length || !/[arudl]/.test(process.argv.slice(2))) {
    program.outputHelp();
    process.exit();
}

program.parse(process.argv);