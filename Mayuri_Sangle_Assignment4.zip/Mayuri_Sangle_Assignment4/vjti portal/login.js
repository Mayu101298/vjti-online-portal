#!/usr/bin/env node

/*
Module name: login.js
Description: Contains the function which passes user input [<Username> and <Password>] to the login() function and validates the user.
@param questions This is an array which contains the parameters given below
@param Username This is the parameter that takes username
@param Password This is the parameter that takes the secure password of the user
Last edited by: Mayurigauri Sangle
Date: 02-10-2018
*/

const program = require('commander');
// Require logic.js file and extract controller functions using JS destructuring assignment
const {
    login
} = require('./logic');

const { prompt } = require('inquirer'); // require inquirerjs library

// Craft questions to present to users
const questions = [
    {
        type: 'input',
        name: 'Username',
        message: 'Enter username ...'
    },
    {
        type: 'input',
        name: 'Password',
        message: 'Enter password ...'
    },
];

program
    .version('0.0.1')
    .description('VJTI Online Portal');

program
    .command('logmein') // No need of specifying arguments here
    .alias('z')
    .description('login user')
    .action(() => {
        // sends user input to login method
        console.info('Enter login details');
        prompt(questions).then(answers =>
            login(answers));
    });

// Assert that a VALID command is provided 
if (!process.argv.slice(2).length || !/[arudl]/.test(process.argv.slice(2))) {
    program.outputHelp();
    process.exit();
}

program.parse(process.argv);