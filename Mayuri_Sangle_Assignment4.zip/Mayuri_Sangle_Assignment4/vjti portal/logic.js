/*
Module name: logic.js
Description: Contains all data schemas, models and all the CRUD (Create, Read, Update, Delete) functions
             required to perform operations such as registering new user, logging in to the VJTI Online
             portal, adding study material and notices by staff and committees, viewing notices and
             committee details.
Last edited by: Mayurigauri Sangle
Date: 02-10-2018
*/

const mongoose = require('mongoose'); // An Object-Document Mapper for Node.js
const assert = require('assert'); // N.B: Assert module comes bundled with Node.js.
mongoose.Promise = global.Promise; // Allows us to use Native promises without throwing error.

// Connect to a single MongoDB instance. The connection string could be that of a remote server
// We assign the connection instance to a constant to be used later in closing the connection
mongoose.connect('mongodb://localhost:27017/contact-manager', { useNewUrlParser: true });
const db = mongoose.connection;

// Converts value to lowercase
function toLower(v) {
    return v.toLowerCase();
}

// Define Schema
const registerSchema = mongoose.Schema({
    // Attribute Name and data type
    Name: { type: String },
    Type_of_user: { type: String },
    ID_No: { type: Number },
    Department: { type: String },
    Username: { type: String },
    Password: { type: String },
    Contact: { type: Number },
    Email: { type: String },
});

const committeeSchema = mongoose.Schema({
    C_name: { type: String },
    Sec_name: { type: String },
    Website: { type: String },
    Contact: { type: Number },
    Email: { type: String },
});

const noticeSchema = mongoose.Schema({
    Notice_No: { type: Number },
    Uploader: { type: String },
    WebLink: { type: String },
    Date: { type: String },
    Department: { type: String },
    Content: { type: String },
});

const notesSchema = mongoose.Schema({
    N_name: { type: String },
    Subject: { type: String },
    Staff_name: { type: String },
    Year: { type: String },
    Department: { type: String },
    Program: { type: String },
    Semester: { type: String },
    Topic: { type: String },
});

const staffdirSchema = mongoose.Schema({
    Staff_name: { type: String },
    Staff_No: { type: String },
    Username: { type: String },
    Designation: { type: String },
    Department: { type: String },
    Qualification: { type: String },
    Subject: { type: String },
    Experience: { type: String },
    Contact: { type: Number },
    Email: { type: String },
    DOB: { type: String },
    Year_Of_Joining: { type: Number },
});

const studentSchema = mongoose.Schema({
    Name: { type: String },
    ID_No: { type: Number },
    Department: { type: String },
    Username: { type: String },
    Password: { type: String },
    Contact: { type: Number },
    Email: { type: String },
});

const staffSchema = mongoose.Schema({
    Name: { type: String },
    Department: { type: String },
    Username: { type: String },
    Password: { type: String },
    Contact: { type: Number },
    Email: { type: String },
});

// Define model as an interface with the database
const Register = mongoose.model('Register', registerSchema);
const Committee = mongoose.model('Committee', committeeSchema);
const Notice = mongoose.model('Notice', noticeSchema);
const Notes = mongoose.model('Notes', notesSchema);
const StaffDir = mongoose.model('StaffDir', staffdirSchema);
const Student = mongoose.model('Student', studentSchema);
const Staff = mongoose.model('Staff', staffSchema);

const login = (user) => {
    // Checks whether Username and Password entered by user matches with the ones stored in Database
    Register.find({ $and: [{ Username: user.Username }, { Password: user.Password }] })
        .exec((err, user) => {
            assert.equal(null, err);
            console.info('Successfully Logged in');
            db.close();
        });
}

const addUser = (user) => {
    // Takes user registration details from register.js inquirer action() function and stores in Database
    Register.create(user, (err) => {
        assert.equal(null, err);
        console.info('New user added');
        if (user.Type_of_user === 'student')
            Student.create(user, (err) => {
                assert.equal(null, err);
                console.info('New student added');
                db.close();
            });
        else if (user.Type_of_user === 'teacher')
            Staff.create(user, (err) => {
                assert.equal(null, err);
                console.info('New staff added');
                db.close();
            });
        else db.close();
    });

};

const addComm = (user) => {
    // Takes committee details from committee.js inquirer action() function and stores in Database
    Committee.create(user, (err) => {
        assert.equal(null, err);
        console.info('New committee added');
        db.close();
    });
};

const addNotice = (user) => {
    // Takes notice details and content from notice.js inquirer action() function and stores in Database
    Notice.create(user, (err) => {
        assert.equal(null, err);
        console.info('New notice added');
        db.close();
    });
};

const addNotes = (user) => {
    // Takes study material content from notes.js inquirer action() function and stores in Database
    Notes.create(user, (err) => {
        assert.equal(null, err);
        console.info('New notes added');
        db.close();
    });
};

const addStaff = (user) => {
    // Takes staff details from staffdir.js inquirer action() function and stores in Database
    StaffDir.create(user, (err) => {
        assert.equal(null, err);
        console.info('staff details added');
        db.close();
    });
};

const getUser = (name) => {
    // Searches for user in database by <Name> of the user
    // Define search criteria. The search here is case-insensitive and inexact.
    const search = new RegExp(name, 'i');
    Register.find({ $or: [{ Name: search }] })
        .exec((err, user) => {
            assert.equal(null, err);
            console.info(user);
            console.info(`${user.length} matches`);
            db.close();
        });
};

const getComm = (name) => {
    // Searches for committee in database by <C_Name> (Committee name)
    // Define search criteria. The search here is case-insensitive and inexact.
    const search = new RegExp(name, 'i');
    Committee.find({ $or: [{ C_name: search }] })
        .exec((err, user) => {
            assert.equal(null, err);
            console.info(user);
            console.info(`${user.length} matches`);
            db.close();
        });
};

const getNotice = (name) => {
    // Searches for notices in database by <Uploader> or <Department>
    // Define search criteria. The search here is case-insensitive and inexact.
    const search = new RegExp(name, 'i');
    Notice.find({ $or: [{ Uploader: search }, { Department: search }] })
        .exec((err, user) => {
            assert.equal(null, err);
            console.info(user);
            console.info(`${user.length} matches`);
            db.close();
        });
};

const getNotes = (name) => {
    // Searches for study material in database by <N_name> or <Subject> or <Department>
    // Define search criteria. The search here is case-insensitive and inexact.
    const search = new RegExp(name, 'i');
    Notes.find({ $or: [{ N_name: search }, { Subject: search }, { Department: search }] })
        .exec((err, user) => {
            assert.equal(null, err);
            console.info(user);
            console.info(`${user.length} matches`);
            db.close();
        });
};

const getStaff = (name) => {
    // Searches for staff details in database by <Staff_name> or <Staff_No> or <Designation> or <Department>
    // Define search criteria. The search here is case-insensitive and inexact.
    const search = new RegExp(name, 'i');
    StaffDir.find({ $or: [{ Staff_name: search }, { Staff_No: search }, { Designation: search }, { Department: search }] })
        .exec((err, user) => {
            assert.equal(null, err);
            console.info(user);
            console.info(`${user.length} matches`);
            db.close();
        });
};

const updateUser = (Name, user) => {
    // Updates user details in the Database
    Register.updateOne({ Name }, user)
        .exec((err, status) => {
            assert.equal(null, err);
            console.info('Updated successfully');
            db.close();
        });
};

const updateComm = (C_name, user) => {
    // Updates committee details in the Database
    Committee.updateOne({ C_name }, user)
        .exec((err, status) => {
            assert.equal(null, err);
            console.info('Updated successfully');
            db.close();
        });
};

const updateNotice = (_id, user) => {
    // Updates notices in the Database
    Notice.updateOne({ _id }, user)
        .exec((err, status) => {
            assert.equal(null, err);
            console.info('Updated successfully');
            db.close();
        });
};

const updateStaff = (Staff_name, user) => {
    // Updates staff details in the Database
    StaffDir.updateOne({ Staff_name }, user)
        .exec((err, status) => {
            assert.equal(null, err);
            console.info('Updated successfully');
            db.close();
        });
};

const deleteUser = (Name) => {
    // Deletes user from Database
    Register.deleteOne({ Name })
        .exec((err, status) => {
            assert.equal(null, err);
            console.info('User Deleted successfully');
            db.close();
        })
};

const deleteComm = (_id) => {
    // Deletes committee from Database
    Committee.deleteOne({ _id })
        .exec((err, status) => {
            assert.equal(null, err);
            console.info('Committee Deleted successfully');
            db.close();
        })
};

const deleteNotice = (_id) => {
    // Deletes notices from Database
    Notice.deleteOne({ _id })
        .exec((err, status) => {
            assert.equal(null, err);
            console.info('Notice Deleted successfully');
            db.close();
        })
};

const deleteNotes = (_id) => {
    // Deletes notes from Database
    Notes.deleteOne({ _id })
        .exec((err, status) => {
            assert.equal(null, err);
            console.info('Notes Deleted successfully');
            db.close();
        })
};

const deleteStaff = (_id) => {
    // Deletes staff from Database
    StaffDir.deleteOne({ _id })
        .exec((err, status) => {
            assert.equal(null, err);
            console.info('staff details Deleted successfully');
            db.close();
        })
};

const getUserList = () => {
    // Prints the list of users present in database
    Register.find()
        .exec((err, users) => {
            assert.equal(null, err);
            console.info(users);
            console.info(`${users.length} matches`);
            db.close();
        })
};

const getCommList = () => {
    // Prints the list of committees present in database
    Committee.find()
        .exec((err, users) => {
            assert.equal(null, err);
            console.info(users);
            console.info(`${users.length} matches`);
            db.close();
        })
};

const getNoticeList = () => {
    // Prints the list of notices present in database
    Notice.find()
        .exec((err, users) => {
            assert.equal(null, err);
            console.info(users);
            console.info(`${users.length} matches`);
            db.close();
        })
};

const getNotesList = () => {
    // Prints the list of notes present in database
    Notes.find()
        .exec((err, users) => {
            assert.equal(null, err);
            console.info(users);
            console.info(`${users.length} matches`);
            db.close();
        })
};

const getStaffList = () => {
    // Prints the list of staff present in database
    StaffDir.find()
        .exec((err, users) => {
            assert.equal(null, err);
            console.info(users);
            console.info(`${users.length} matches`);
            db.close();
        })
};


// Export all methods
module.exports = {
    login,
    addUser,
    getUser,
    getUserList,
    updateUser,
    deleteUser,
    addComm,
    getComm,
    getCommList,
    updateComm,
    deleteComm,
    addNotice,
    getNotice,
    getNoticeList,
    updateNotice,
    deleteNotice,
    addNotes,
    getNotes,
    getNotesList,
    deleteNotes,
    addStaff,
    getStaff,
    updateStaff,
    deleteStaff,
    getStaffList
};