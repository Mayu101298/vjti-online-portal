#!/usr/bin/env node

/*
Module name: notes.js
Description: Contains the function which passes study material details to store in the database and perform other operations.
Module name: notes.js
@param questions This is an array which contains the parameters given below
@param N_name This is the parameter that takes title of the notes
@param Subject This is the parameter that takes subject of the notes
@param Staff_name This is the parameter that takes name of the staff who wants to add notes
@param Year This is the parameter that takes academic year of the batch for which the notes is intended
@param Department This is the parameter that takes the department name for which the notes is intended
@param Program This is the parameter that takes program name
@param Semester This is the parameter that takes the semester
@param Topic This is the parameter that takes short description of the topic

Last edited by: Mayurigauri Sangle
Date: 03-10-2018
*/

const program = require('commander');
// Require logic.js file and extract controller functions using JS destructuring assignment
const {
    addNotes,
    getNotes,
    getNotesList,
    deleteNotes
} = require('./logic');

const { prompt } = require('inquirer'); // require inquirerjs library

// Craft questions to present to users
const questions = [
    {
        type: 'input',
        name: 'N_name',
        message: 'Enter notes title ...'
    },
    {
        type: 'input',
        name: 'Subject',
        message: 'Enter subject name ...'
    },
    {
        type: 'input',
        name: 'Staff_name',
        message: 'Enter staff name ...'
    },
    {
        type: 'input',
        name: 'Year',
        message: 'Enter year ...'
    },
    {
        type: 'input',
        name: 'Department',
        message: 'Enter department ...'
    },
    {
        type: 'input',
        name: 'Program',
        message: 'Enter program ...'
    },
    {
        type: 'input',
        name: 'Semester',
        message: 'Enter semester ...'
    },
    {
        type: 'input',
        name: 'Topic',
        message: 'Enter a short topic description ...'
    }
];

program
    .version('0.0.1')
    .description('VJTI Online Portal');

program
    .command('addNotes') // No need of specifying arguments here
    .alias('a')
    .description('Add notes')
    .action(() => {
        // sends user input to addNotes method
        prompt(questions).then(answers =>
            addNotes(answers));
    });

program
    .command('getNotes <name>')
    .alias('r')
    .description('Get notes')
    .action(name => getNotes(name)); // sends user input to getNotes method

program
    .command('deleteNotes <_id>')
    .alias('d')
    .description('Delete notes')
    .action(_id => deleteNotes(_id)); // sends user input to deleteNotes method

program
    .command('getNotesList')
    .alias('l')
    .description('List notes')
    .action(() => getNotesList()); // sends user input to getNotesList method

// Assert that a VALID command is provided 
if (!process.argv.slice(2).length || !/[arudl]/.test(process.argv.slice(2))) {
    program.outputHelp();
    process.exit();
}

program.parse(process.argv);