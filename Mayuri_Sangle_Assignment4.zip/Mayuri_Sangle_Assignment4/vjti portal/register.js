#!/usr/bin/env node

/*
Module name: register.js
Description: Contains the function which passes user registration details to store in the database. 
@param questions This is an array which contains the parameters given below
@param Name This is the parameter that takes name of the user
@param Type_of_user This is the parameter that takes type of the user
@param ID_No This is the parameter that takes the ID number of the user
@param Department This is the parameter that takes the department name of the user
@param Username This is the parameter that takes the username
@param Password This is the parameter that takes the user password
@param Contact This is the parameter that takes the contact number of the user
@param Email This is the parameter that takes the user email address
Last edited by: Mayurigauri Sangle
Date: 02-10-2018
*/

const program = require('commander');
// Require logic.js file and extract controller functions using JS destructuring assignment
const {
    addUser,
    getUser,
    getUserList,
    updateUser,
    deleteUser
} = require('./logic');

const { prompt } = require('inquirer'); // require inquirerjs library

// Craft questions to present to users
const questions = [
    {
        type: 'input',
        name: 'Name',
        message: 'Enter name ...'
    },
    {
        type: 'input',
        name: 'Type_of_user',
        message: 'Enter user type (student or teacher or committee or admin) ...'
    },
    {
        type: 'input',
        name: 'ID_No',
        message: 'Enter ID number ...'
    },
    {
        type: 'input',
        name: 'Department',
        message: 'Enter department ...'
    },
    {
        type: 'input',
        name: 'Username',
        message: 'Choose a username ...'
    },
    {
        type: 'input',
        name: 'Password',
        message: 'Enter password ...'
    },
    {
        type: 'input',
        name: 'Contact',
        message: 'Enter phone number ...'
    },
    {
        type: 'input',
        name: 'Email',
        message: 'Enter email address ...'
    }
];

program
    .version('0.0.1')
    .description('VJTI Online Portal');

program
    .command('addUser') // No need of specifying arguments here
    .alias('a')
    .description('Add a user')
    .action(() => {
        // sends user input to addUser method
        prompt(questions).then(answers =>
            addUser(answers));
    });

program
    .command('getUser <name>')
    .alias('r')
    .description('Get user')
    .action(name => getUser(name)); // sends user input to getUser method

program
    .command('updateUser <_id>')
    .alias('u')
    .description('Update user')
    .action(_id => {
        // sends user input to updateUser method
        prompt(questions).then((answers) =>
            updateUser(_id, answers));
    });

program
    .command('deleteUser <_id>')
    .alias('d')
    .description('Delete user')
    .action(_id => deleteUser(_id)); // sends user input to deleteUser method

program
    .command('getUserList')
    .alias('l')
    .description('List users')
    .action(() => getUserList()); // sends user input to getUserList method

// Assert that a VALID command is provided 
if (!process.argv.slice(2).length || !/[arudl]/.test(process.argv.slice(2))) {
    program.outputHelp();
    process.exit();
}

program.parse(process.argv);