#!/usr/bin/env node

/*
Module name: staffdir.js
Description: Contains the function which passes staff details to store in the database and perform other operations.
Module name: staffdir.js
@param questions This is an array which contains the parameters given below
@param Staff_name This is the parameter that takes name of the staff
@param Staff_No This is the parameter that takes the unique staff number
@param Username This is the parameter that takes the Username of the staff
@param Designation This is the parameter that takes designation of the staff
@param Department This is the parameter that takes the department name of the staff
@param Qualification This is the parameter that takes the qualification
@param Subject This is the parameter that takes subject which the staff teaches
@param Experience This is the parameter that takes years of experience of the staff
@param Contact This is the parameter that takes the contact number of the staff
@param Email This is the parameter that takes the user email address
@param DOB This is the parameter that takes the date of birth
@param Year_Of_Joining This is the parameter that takes the year of joining
Last edited by: Mayurigauri Sangle
Date: 05-10-2018
*/

const program = require('commander');
// Require logic.js file and extract controller functions using JS destructuring assignment
const {
    addStaff,
    getStaff,
    updateStaff,
    deleteStaff,
    getStaffList
} = require('./logic');

const { prompt } = require('inquirer'); // require inquirerjs library

// Craft questions to present to users
const questions = [
    {
        type: 'input',
        name: 'Staff_name',
        message: 'Enter staff name ...'
    },
    {
        type: 'input',
        name: 'Staff_No',
        message: 'Enter staff number ...'
    },
    {
        type: 'input',
        name: 'Username',
        message: 'Enter username ...'
    },
    {
        type: 'input',
        name: 'Designation',
        message: 'Enter designation ...'
    },
    {
        type: 'input',
        name: 'Department',
        message: 'Enter department ...'
    },
    {
        type: 'input',
        name: 'Qualification',
        message: 'Enter qualification ...'
    },
    {
        type: 'input',
        name: 'Subject',
        message: 'Enter subject ...'
    },
    {
        type: 'input',
        name: 'Experience',
        message: 'Enter years of experience ...'
    },
    {
        type: 'input',
        name: 'Contact',
        message: 'Enter contact number ...'
    },
    {
        type: 'input',
        name: 'Email',
        message: 'Enter email address ...'
    },
    {
        type: 'input',
        name: 'DOB',
        message: 'Enter date of birth ...'
    },
    {
        type: 'input',
        name: 'Year_Of_Joining',
        message: 'Enter year of joining ...'
    }
];

program
    .version('0.0.1')
    .description('VJTI Online Portal');

program
    .command('addStaff') // No need of specifying arguments here
    .alias('a')
    .description('Add staff details')
    .action(() => {
        // sends user input to addStaff method
        prompt(questions).then(answers =>
            addStaff(answers));
    });

program
    .command('getStaff <name>')
    .alias('r')
    .description('Get staff details')
    .action(name => getStaff(name)); // sends user input to getStaff method

program
    .command('updateStaff <_id>')
    .alias('u')
    .description('Update staff details')
    .action(_id => {
        // sends user input to updateStaff method
        prompt(questions).then((answers) =>
            updateStaff(_id, answers));
    });

program
    .command('deleteStaff <_id>')
    .alias('d')
    .description('Delete staff details')
    .action(_id => deleteStaff(_id)); // sends user input to deleteStaff method

program
    .command('getStaffList')
    .alias('l')
    .description('List staff details')
    .action(() => getStaffList()); // sends user input to getStaffList method

// Assert that a VALID command is provided 
if (!process.argv.slice(2).length || !/[arudl]/.test(process.argv.slice(2))) {
    program.outputHelp();
    process.exit();
}

program.parse(process.argv);