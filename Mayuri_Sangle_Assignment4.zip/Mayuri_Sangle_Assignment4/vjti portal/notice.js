#!/usr/bin/env node

/*
Module name: notice.js
Description: Contains the function which passes notice to store in the database and perform other operations.
@param questions This is an array which contains the parameters given below
@param Notice_No This is the parameter that takes notice number
@param Uploader This is the parameter that takes name of the staff who wants to add notice
@param WebLink This is the parameter that takes website link related to the notice
@param Date This is the parameter that takes the date on which notice is added
@param Department This is the parameter that takes the department name for which the notice is intended
@param Content This is the parameter that takes the content of the notice
Last edited by: Mayurigauri Sangle
Date: 03-10-2018
*/

const program = require('commander');
// Require logic.js file and extract controller functions using JS destructuring assignment
const {
    addNotice,
    getNotice,
    getNoticeList,
    updateNotice,
    deleteNotice
} = require('./logic');

const { prompt } = require('inquirer'); // require inquirerjs library

// Craft questions to present to users
const questions = [
    {
        type: 'input',
        name: 'Notice_No',
        message: 'Enter notice number ...'
    },
    {
        type: 'input',
        name: 'Uploader',
        message: 'Enter uploader name ...'
    },
    {
        type: 'input',
        name: 'WebLink',
        message: 'Enter link to refer ...'
    },
    {
        type: 'input',
        name: 'Date',
        message: 'Enter date ...'
    },
    {
        type: 'input',
        name: 'Department',
        message: 'Enter department ...'
    },
    {
        type: 'input',
        name: 'Content',
        message: 'Enter notice content ...'
    }
];

program
    .version('0.0.1')
    .description('VJTI Online Portal');

program
    .command('addNotice') // No need of specifying arguments here
    .alias('a')
    .description('Add a notice')
    .action(() => {
        // sends user input to addNotice method
        prompt(questions).then(answers =>
            addNotice(answers));
    });

program
    .command('getNotice <name>')
    .alias('r')
    .description('Get notice')
    .action(name => getNotice(name)); // sends user input to getNotice method

program
    .command('updateNotice <_id>')
    .alias('u')
    .description('Update notice')
    .action(_id => {
        // sends user input to updateNotice method
        prompt(questions).then((answers) =>
            updateNotice(_id, answers));
    });

program
    .command('deleteNotice <_id>')
    .alias('d')
    .description('Delete notice')
    .action(_id => deleteNotice(_id)); // sends user input to deleteNotice method

program
    .command('getNoticeList')
    .alias('l')
    .description('List notices')
    .action(() => getNoticeList()); // sends user input to getNoticeList method

// Assert that a VALID command is provided 
if (!process.argv.slice(2).length || !/[arudl]/.test(process.argv.slice(2))) {
    program.outputHelp();
    process.exit();
}

program.parse(process.argv);